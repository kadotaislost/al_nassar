<?php
echo "<hr>";
echo "&copy;".date("Y").", mysite.com, all right reserved.";
?>