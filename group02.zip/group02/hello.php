<?php
$date=date('Y-m-d');
echo "<p>Today is $date </p>";
echo "HEllo World";
?>
